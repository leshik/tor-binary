
# Copyright (c) Twisted Matrix Laboratories.
# See LICENSE for details.


"""
Twisted Spread UI: UI utilities for various toolkits connecting to PB.
"""

# Undeprecating this until someone figures out a real plan for alternatives to spread.ui.
##import warnings
##warnings.warn("twisted.spread.ui is deprecated. Please do not use.", DeprecationWarning)
