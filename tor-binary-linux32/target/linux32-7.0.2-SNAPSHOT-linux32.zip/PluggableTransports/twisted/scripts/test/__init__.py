# Copyright (c) Twisted Matrix Laboratories.
# See LICENSE for details.

"""
Test package for L{twisted.scripts}.
"""
